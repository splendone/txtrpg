Overview
-------
This project was developed as a response to the large number of beginning Python developer who want to learn how to write a text adventure.

Although there are many approaches, this project is designed to be expandable with "pluggable" elements.

Tutorial
--------
For an in-depth tutorial, please see [How to Write a Text Adventure in Python](http://letstalkdata.com/2014/08/how-to-write-a-text-adventure-in-python/).